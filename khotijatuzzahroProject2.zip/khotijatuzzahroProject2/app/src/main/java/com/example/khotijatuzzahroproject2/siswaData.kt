package com.example.khotijatuzzahroproject2

data class siswaData(
    val nama:String,
    val nis:String,
    val jekel:String
)